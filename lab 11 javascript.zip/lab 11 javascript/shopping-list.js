document.addEventListener('DOMContentLoaded', function() {
    // Step 1: Create variables that hold references to the list, input, and button elements.
    var shoppingList = document.getElementById('shoppingList');
    var inputElement = document.getElementById('item');
    var addItemBtn = document.getElementById('addItemBtn');
  
    // Step 2: Create a function that runs in response to the button being clicked.
    addItemBtn.addEventListener('click', function() {
      // Step 3: Store the current value of the input element in a variable.
      var newItem = inputElement.value;
  
      // Step 4: Empty the input element by setting its value to an empty string.
      inputElement.value = '';
  
      // Step 5: Create new elements — a list item (<li>), <span>, and <button>.
      var listItem = document.createElement('li');
      var itemSpan = document.createElement('span');
      var deleteButton = document.createElement('button');
  
      // Step 6: Append the span and the button as children of the list item.
      listItem.appendChild(itemSpan);
      listItem.appendChild(deleteButton);
  
      // Step 7: Set the text content of the span and the button.
      itemSpan.textContent = newItem;
      deleteButton.textContent = 'Delete';
  
      // Step 8: Append the list item as a child of the list.
      shoppingList.appendChild(listItem);
  
      // Step 9: Attach an event handler to the delete button to remove the list item when clicked.
      deleteButton.addEventListener('click', function() {
        shoppingList.removeChild(listItem);
      });
  
      // Step 10: Use the focus() method to focus the input element.
      inputElement.focus();
    });
  });
  